#include "Person.h"
#include "SharedPtr.h"


void test_creation_Person()
{
   std::cout<<"----------------------In test Person--------------------------------"<< std::endl;

  /*SharedPtr<Person> ptr;
  SharedPtr<Person> ptr1_Person(new Person("Elisheva",111,20));
  ptr1_Person->print();	
  */
  SharedPtr<Person> ptr2_Person(new Person()); 


  ptr2_Person->print();

  SharedPtr<Person> ptr3_Person(new Person("Ruchami",222,22)); 
  ptr3_Person->print();

 ptr2_Person =ptr3_Person; 
   std::cout<<"----------------------End test Person--------------------------------" << std::endl;		
}


int main()
{
   test_creation_Person();
	
	return 1;
}
